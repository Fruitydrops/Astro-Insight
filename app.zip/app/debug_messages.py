#!/usr/bin/env python3
import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.graph.nodes import coordinator_node
from src.graph.types import State

async def test_coordinator():
    """测试协调器节点"""
    print("测试协调器节点...")
    
    # 创建测试状态
    state = State(
        messages=[{"role": "user", "content": "你好"}],
        user_role="unknown",
        current_step="greeting",
        processing_status="idle"
    )
    
    print(f"初始状态: {state}")
    
    # 执行协调器节点
    result = await coordinator_node(state)
    
    print(f"协调器节点结果: {result}")
    
    # 检查消息
    if "messages" in result:
        print(f"消息数量: {len(result['messages'])}")
        for i, msg in enumerate(result["messages"]):
            print(f"消息 {i}: {msg}")

if __name__ == "__main__":
    asyncio.run(test_coordinator())



