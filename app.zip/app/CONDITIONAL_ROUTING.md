# 条件路由功能说明

## 概述

本项目实现了基于用户身份的条件路由功能，根据用户类型（非专业人士或专业人士）自动跳转到相应的服务节点。

## 功能特性

### 🔄 条件路由逻辑

- **非专业人士（天文爱好者）** → 跳转到 `QA_Agent` 节点
- **专业人士（天文研究者）** → 跳转到 `Task_Selector_Node` 节点

### 📋 节点功能

#### 1. QA_Agent 节点
- **目标用户**: 天文爱好者、学生、对天文感兴趣的用户
- **服务内容**:
  - 🌌 宇宙基础知识解答
  - 🔭 天文观测技巧和器材推荐
  - 🌙 月相变化和天体运动规律
  - ☄️ 流星雨、彗星等天文现象
  - 🌍 地球在宇宙中的位置
  - 🚀 太空探索和航天知识
  - 📅 天文历法和时间计算

#### 2. Task_Selector_Node 节点
- **目标用户**: 专业天文研究者、科学家、相关专业人士
- **服务内容**:
  - 📊 天体观测数据处理与分析
  - 📈 科学计算工具（轨道计算、天体位置计算等）
  - 📋 研究支持（科学图表生成、数据可视化等）
  - 🔧 专业工具（天体数据库查询、观测计划制定等）

## 工作流程

```
开始 → 问候节点 → 身份检查节点 → 条件路由
                                    ↓
                            ┌─────────────────┐
                            │   用户身份判断    │
                            └─────────────────┘
                                    ↓
                    ┌─────────────────────────────┐
                    │                             │
                    ▼                             ▼
            ┌─────────────┐               ┌─────────────┐
            │  QA_Agent   │               │Task_Selector│
            │   (爱好者)   │               │  (专业人士)  │
            └─────────────┘               └─────────────┘
```

## 技术实现

### 路由函数

1. **`route_after_identity_check(state: State) -> str`**
   - 身份检查后的主要路由函数
   - 根据 `detected_user_role` 字段决定跳转目标

2. **`route_by_user_type(state: State) -> str`**
   - 通用用户类型路由函数
   - 支持节点间的动态跳转

### 状态管理

- `detected_user_role`: 存储检测到的用户身份
  - `"professional"`: 专业人士
  - `"enthusiast"`: 天文爱好者
  - `"unknown"`: 未确认身份

### 图结构

```python
graph = (
    StateGraph(State, context_schema=Context)
    .add_node("greeting", greeting_node)
    .add_node("identity_checker", identity_checker_node)
    .add_node("identity_query", identity_query_node)
    .add_node("qa_agent", qa_agent_node)           # 新增
    .add_node("task_selector", task_selector_node) # 新增
    .add_edge("__start__", "greeting")
    .add_edge("greeting", "identity_checker")
    .add_conditional_edges(
        "identity_checker",
        route_after_identity_check,
        {
            "qa_agent": "qa_agent",
            "task_selector": "task_selector",
            "__end__": "__end__"
        }
    )
    # ... 其他条件边
)
```

## 使用方法

### 1. 启动代理

```python
from src.agent.graph import graph
from src.agent.config.state import State

# 创建初始状态
state = State(
    user_query="我是天文爱好者",  # 或 "我是专业研究者"
    conversation_history=[],
    current_step="idle"
)

# 配置
config = {
    "configurable": {
        "language": "zh",
        "user_role": "unknown"
    }
}

# 运行图
result = await graph.ainvoke(state, config=config)
```

### 2. 测试条件路由

运行测试脚本：

```bash
cd to/your/app
python test_conditional_routing.py
```

## 扩展性

### 添加新的用户类型

1. 在 `State` 类中添加新的用户角色标识
2. 创建对应的服务节点
3. 更新路由函数以支持新的用户类型
4. 在图结构中添加新的条件边

### 自定义服务内容

- 修改 `qa_agent_node` 和 `task_selector_node` 中的响应内容
- 根据具体需求调整服务功能
- 添加更多的专业工具和分析功能

## 注意事项

- 确保用户身份识别逻辑准确可靠
- 保持节点间的状态一致性
- 处理异常情况和错误路由
- 支持多语言环境下的正确路由

## 文件结构

```
src/agent/
├── graph.py                    # 主图定义和路由逻辑
├── nodes/
│   ├── __init__.py            # 节点模块导入
│   ├── greeting.py            # 问候节点
│   ├── identity_checker.py    # 身份检查节点
│   ├── identity_query.py      # 身份查询节点
│   ├── qa_agent.py           # QA代理节点 (新增)
│   └── task_selector.py      # 任务选择器节点 (新增)
└── config/
    ├── state.py              # 状态定义
    └── context.py            # 上下文定义
```

