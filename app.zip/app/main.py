# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

"""
Entry point script for the Astronomy Agent project.
"""

import argparse
import asyncio

from src.workflow import run_astronomy_workflow_async
from src.graph import build_graph_with_memory


def ask(
    question,
    debug=False,
    max_task_iterations=1,
    enable_background_investigation=True,
):
    """Run the astronomy agent workflow with the given question.

    Args:
        question: The user's query or request
        debug: If True, enables debug level logging
        max_task_iterations: Maximum number of task iterations
        enable_background_investigation: If True, performs background research before task execution
    """
    asyncio.run(
        run_astronomy_workflow_async(
            user_input=question,
            debug=debug,
            max_task_iterations=max_task_iterations,
            enable_background_investigation=enable_background_investigation,
        )
    )


def main(
    debug=False,
    max_task_iterations=1,
    enable_background_investigation=True,
):
    """Interactive mode for astronomy agent.

    Args:
        enable_background_investigation: If True, performs background research before task execution
        debug: If True, enables debug level logging
        max_task_iterations: Maximum number of task iterations
    """
    print("🌟 天文科研智能代理")
    print("=" * 50)
    print("💡 输入 'exit' 或 'quit' 退出程序")
    print("=" * 50)
    
    # 使用带记忆的图
    graph = build_graph_with_memory()
    
    while True:
        try:
            user_input = input("\n👤 您: ").strip()
            
            if user_input.lower() in ['exit', 'quit', '退出']:
                print("👋 再见！")
                break
            
            if not user_input:
                continue
            
            print("🔄 处理中...")
            
            # 使用LangGraph的checkpointer来管理状态
            config = {
                "configurable": {
                    "thread_id": "conversation",  # 使用固定的thread_id来保持对话历史
                    "max_task_iterations": max_task_iterations,
                }
            }
            
            # 运行工作流，状态会自动保存和恢复
            asyncio.run(
                run_astronomy_workflow_async(
                    user_input=user_input,
                    debug=debug,
                    max_task_iterations=max_task_iterations,
                    enable_background_investigation=enable_background_investigation,
                )
            )
            
        except KeyboardInterrupt:
            print("\n👋 再见！")
            break
        except Exception as e:
            print(f"❌ 发生错误: {e}")
            print("请重试...")


if __name__ == "__main__":
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Run the Astronomy Agent")
    parser.add_argument("query", nargs="*", help="The query to process")
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Run in interactive mode",
    )
    parser.add_argument(
        "--max_task_iterations",
        type=int,
        default=1,
        help="Maximum number of task iterations (default: 1)",
    )
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument(
        "--no-background-investigation",
        action="store_false",
        dest="enable_background_investigation",
        help="Disable background investigation before task execution",
    )

    args = parser.parse_args()

    if args.interactive:
        # Pass command line arguments to main function
        main(
            debug=args.debug,
            max_task_iterations=args.max_task_iterations,
            enable_background_investigation=args.enable_background_investigation,
        )
    else:
        # Parse user input from command line arguments or user input
        if args.query:
            user_query = " ".join(args.query)
        else:
            # Loop until user provides non-empty input
            while True:
                user_query = input("Enter your query: ")
                if user_query is not None and user_query != "":
                    break

        # Run the astronomy agent workflow with the provided parameters
        ask(
            question=user_query,
            debug=args.debug,
            max_task_iterations=args.max_task_iterations,
            enable_background_investigation=args.enable_background_investigation,
        )
