#!/usr/bin/env python3
"""
交互式测试记忆功能
"""

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def interactive_test():
    """交互式测试记忆功能"""
    print("🧪 交互式记忆功能测试")
    print("=" * 50)
    print("请按顺序输入以下内容来测试记忆功能：")
    print("1. 爱好者")
    print("2. 天文观测技巧") 
    print("3. 我的第一个问题是什么")
    print("4. quit")
    print("=" * 50)
    
    while True:
        try:
            user_input = input("\n👤 您: ").strip()
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("👋 再见！")
                break
            
            print("🔄 处理中...")
            await run_astronomy_workflow_async(user_input, debug=True)
            
        except KeyboardInterrupt:
            print("\n👋 再见！")
            break
        except Exception as e:
            print(f"❌ 错误: {e}")

if __name__ == "__main__":
    asyncio.run(interactive_test())

