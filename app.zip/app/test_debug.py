#!/usr/bin/env python3
import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def test_debug():
    """调试测试"""
    print("开始调试测试...")
    
    # 测试协调器节点
    await run_astronomy_workflow_async("你好", debug=True)
    
    print("\n" + "="*50)
    print("测试完成")

if __name__ == "__main__":
    asyncio.run(test_debug())



