#!/usr/bin/env python3
# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

class InteractiveAstronomyAgent:
    """交互式天文代理"""
    
    def __init__(self, debug=False):
        self.debug = debug
        self.conversation_history = []
        self.user_role = "unknown"
        self.current_step = "greeting"
        
    async def process_user_input(self, user_input: str):
        """处理用户输入"""
        print("🔄 处理中...")
        
        # 添加用户消息到历史
        self.conversation_history.append({"role": "user", "content": user_input})
        
        # 运行工作流
        await run_astronomy_workflow_async(
            user_input=user_input,
            debug=self.debug,
            max_task_iterations=1,
            enable_background_investigation=True,
        )
        
        print("\n" + "="*50)
    
    async def run(self):
        """运行交互式代理"""
        print("🌟 天文科研智能代理")
        print("=" * 50)
        print("💡 输入 'exit' 或 'quit' 退出程序")
        print("=" * 50)
        
        while True:
            try:
                user_input = input("\n👤 您: ").strip()
                
                if user_input.lower() in ['exit', 'quit', '退出']:
                    print("👋 再见！")
                    break
                
                if not user_input:
                    continue
                
                await self.process_user_input(user_input)
                
            except KeyboardInterrupt:
                print("\n👋 再见！")
                break
            except Exception as e:
                print(f"❌ 发生错误: {e}")
                print("请重试...")

async def main():
    """主函数"""
    agent = InteractiveAstronomyAgent(debug=False)
    await agent.run()

if __name__ == "__main__":
    asyncio.run(main())



