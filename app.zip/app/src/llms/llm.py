# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from typing import Dict, Any
from langchain_community.llms import Ollama
from langchain_core.language_models import BaseChatModel

# Cache for LLM instances
_llm_cache: Dict[str, BaseChatModel] = {}


def get_llm(llm_type: str = "basic") -> BaseChatModel:
    """获取LLM实例"""
    if llm_type not in _llm_cache:
        if llm_type == "basic":
            _llm_cache[llm_type] = Ollama(
                model="qwen2.5:7b",
                temperature=0.7,
                top_p=0.9,
            )
        else:
            # 默认使用basic模型
            _llm_cache[llm_type] = Ollama(
                model="qwen2.5:7b",
                temperature=0.7,
                top_p=0.9,
            )
    
    return _llm_cache[llm_type]



