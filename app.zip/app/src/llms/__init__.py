# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from .llm import get_llm

__all__ = ["get_llm"]



