# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import logging

from src.config.configuration import get_recursion_limit
from src.graph import build_graph_with_memory

# Configure logging
logging.basicConfig(
    level=logging.INFO,  # Default level is INFO
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)


def enable_debug_logging():
    """Enable debug level logging for more detailed execution information."""
    logging.getLogger("src").setLevel(logging.DEBUG)


logger = logging.getLogger(__name__)

# Create the graph with memory - 全局共享实例
graph = build_graph_with_memory()

# 全局对话历史存储
conversation_history = []

async def run_astronomy_workflow_async(
    user_input: str,
    debug: bool = False,
    max_task_iterations: int = 1,
    enable_background_investigation: bool = True,
):
    """Run the astronomy agent workflow asynchronously with the given user input.

    Args:
        user_input: The user's query or request
        debug: If True, enables debug level logging
        max_task_iterations: Maximum number of task iterations
        enable_background_investigation: If True, performs background research before task execution

    Returns:
        The final state after the workflow completes
    """
    if not user_input:
        raise ValueError("Input could not be empty")

    if debug:
        enable_debug_logging()

    logger.info(f"Starting async astronomy workflow with user input: {user_input}")
    
    # 添加新的用户消息到对话历史
    conversation_history.append({"role": "user", "content": user_input})
    
    # 参考deer-flow的实现：只添加新的用户消息，让checkpointer恢复之前的状态
    initial_state = {
        "messages": [{"role": "user", "content": user_input}],
        "auto_accepted_task": True,
        "enable_background_investigation": enable_background_investigation,
    }
    config = {
        "configurable": {
            "thread_id": "conversation",  # 使用固定的thread_id来保持对话历史
            "max_task_iterations": max_task_iterations,
        },
        "recursion_limit": get_recursion_limit(default=100),
    }
    last_message_cnt = 0
    async for s in graph.astream(
        input=initial_state, config=config, stream_mode="values"
    ):
        try:
            if isinstance(s, dict) and "messages" in s:
                if len(s["messages"]) <= last_message_cnt:
                    continue
                last_message_cnt = len(s["messages"])
                message = s["messages"][-1]
                if isinstance(message, tuple):
                    print(message)
                else:
                    # 使用deer-flow的方式处理消息
                    if hasattr(message, 'pretty_print'):
                        message.pretty_print()
                    else:
                        # 如果是字典格式的消息
                        content = message.get('content', '') if isinstance(message, dict) else str(message)
                        if content and not content.startswith('content='):
                            print(f"🤖 代理: {content}")
            else:
                # For any other output format
                print(f"Output: {s}")
        except Exception as e:
            logger.error(f"Error processing stream output: {e}")
            print(f"Error processing output: {str(e)}")

    # 将AI的回复添加到对话历史中
    if conversation_history and conversation_history[-1]["role"] == "user":
        # 如果最后一条是用户消息，添加AI回复
        conversation_history.append({"role": "assistant", "content": "已处理您的请求"})
    
    if debug:
        logger.info("Async astronomy workflow completed successfully")


if __name__ == "__main__":
    print(graph.get_graph(xray=True).draw_mermaid())
