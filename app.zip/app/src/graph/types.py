# 状态类型定义 - 仿照deer-flow
from langgraph.graph import MessagesState
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field

@dataclass
class AstronomyTask:
    """天文任务定义"""
    task_type: str = ""  # "classification", "data_retrieval", "literature_review", "background_investigation"
    target_object: str = ""  # 目标天体对象
    data_source: str = ""  # 数据源
    classification_standard: str = ""  # 分类标准
    parameters: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ExecutionResult:
    """执行结果定义"""
    version: str = "v1"
    code: str = ""
    output: str = ""
    success: bool = False
    error_message: str = ""

class State(MessagesState):
    """天文代理状态，扩展MessagesState"""
    
    # 用户身份和偏好
    user_role: str = "unknown"  # "enthusiast" | "professional" | "unknown"
    locale: str = "zh-CN"  # 语言和地区设置
    
    # 任务相关
    current_task: Optional[AstronomyTask] = None
    task_iterations: int = 0
    auto_accepted_task: bool = False
    
    # 天文数据
    celestial_objects: List[Dict[str, Any]] = field(default_factory=list)
    observation_data: Optional[Dict[str, Any]] = None
    research_resources: List[Dict[str, Any]] = field(default_factory=list)
    
    # 执行结果
    current_plan: str = ""
    execution_result: Optional[ExecutionResult] = None
    final_report: str = ""
    
    # 流程控制
    current_step: str = "greeting"
    processing_status: str = "idle"
    needs_human_feedback: bool = False
    enable_background_investigation: bool = True
    background_investigation_results: str = ""
