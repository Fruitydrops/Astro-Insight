# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import logging
from typing import Dict, Any, List
from langchain_community.llms import Ollama
from langchain.tools import Tool
from langchain.agents import create_react_agent, AgentExecutor
from langchain import hub
from langchain_core.messages import HumanMessage, AIMessage

from .types import State, AstronomyTask, ExecutionResult
from src.llms import get_llm
from src.tools import get_web_search_tool

logger = logging.getLogger(__name__)


async def coordinator_node(state: State) -> Dict[str, Any]:
    """协调器节点 - 仿照deer-flow的coordinator"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行协调器节点")
    
    # 检查是否已经有用户消息
    messages = state.get("messages", [])
    if not messages:
        return {
            "messages": [{
                "role": "assistant",
                "content": """🌟 欢迎使用天文科研智能代理！

我是您的专业天文研究助手，可以为您提供：
• 天体观测数据分析
• 科学图表生成  
• 天文知识解答
• 专业研究任务执行

现在让我了解一下您的身份，以便为您提供最合适的服务。

请告诉我您的身份：
• 回复 '爱好者' - 如果您是天文爱好者
• 回复 '专业' - 如果您是专业研究者"""
            }],
            "current_step": "user_profiling",
            "processing_status": "awaiting_input"
        }
    
    # 检查对话历史中是否有身份信息
    for message in messages:
        if isinstance(message, dict) and message.get("role") == "assistant":
            content = message.get("content", "")
            if "🌟 欢迎！我是您的天文小助手" in content:
                # 已经识别为爱好者，直接进入问答模式
                return {
                    "user_role": "enthusiast",
                    "current_step": "qa_agent",
                    "processing_status": "ready"
                }
            elif "🔬 欢迎！我是您的专业天文研究助手" in content:
                # 已经识别为专业研究者，直接进入任务选择模式
                return {
                    "user_role": "professional",
                    "current_step": "task_selector",
                    "processing_status": "ready"
                }
    
    # 如果还没有识别身份，进入用户画像
    return {
        "current_step": "user_profiling",
        "processing_status": "awaiting_input"
    }


async def user_profiler_node(state: State) -> Dict[str, Any]:
    """用户画像节点 - 识别用户身份"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行用户画像节点")
    
    # 检查是否已经识别过身份
    current_user_role = state.get("user_role", "unknown")
    if current_user_role != "unknown":
        # 已经识别过身份，保持当前状态并继续处理用户输入
        return {
            "user_role": current_user_role,
            "processing_status": "ready"
        }
    
    # 检查对话历史中是否有身份信息
    messages = state.get("messages", [])
    for message in messages:
        if isinstance(message, dict) and message.get("role") == "assistant":
            content = message.get("content", "")
            if "🌟 欢迎！我是您的天文小助手" in content:
                # 已经识别为爱好者
                return {
                    "user_role": "enthusiast",
                    "processing_status": "ready"
                }
            elif "🔬 欢迎！我是您的专业天文研究助手" in content:
                # 已经识别为专业研究者
                return {
                    "user_role": "professional",
                    "processing_status": "ready"
                }
    
    # 获取最后一条用户消息
    messages = state.get("messages", [])
    if not messages:
        return {"processing_status": "error"}
    
    last_message = messages[-1]
    
    # 正确提取用户输入内容
    if isinstance(last_message, dict):
        user_input = last_message.get("content", "")
    else:
        # 如果是消息对象，尝试获取content属性
        user_input = getattr(last_message, 'content', str(last_message))
    
    print(f"DEBUG: user_profiler_node 收到输入: '{user_input}'")
    
    # 检查身份
    print(f"DEBUG: 检查身份，user_input='{user_input}'")
    if user_input in ["爱好者", "爱好", "enthusiast", "天文爱好者"]:
        print("DEBUG: 识别为爱好者")
        user_role = "enthusiast"
        welcome_msg = """🌟 欢迎！我是您的天文小助手

作为天文爱好者，您可以向我提问任何关于宇宙的知识性问题，包括：
• 天体观测技巧
• 天文现象解释
• 星空观测指南
• 天文器材推荐

请告诉我您想了解什么？"""
        
    elif user_input in ["专业", "professional", "研究者", "科学家"]:
        user_role = "professional"
        welcome_msg = """🔬 欢迎！我是您的专业天文研究助手

作为专业研究者，我可以为您提供：
• 天体数据分析
• 科学计算工具
• 文献检索辅助
• 研究任务执行

请选择您需要的服务类型。"""
        
    else:
        # 如果不是身份选择，要求用户明确身份
        return {
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": "请告诉我您的身份：\n• 回复 '爱好者' - 如果您是天文爱好者\n• 回复 '专业' - 如果您是专业研究者"
            }],
            "processing_status": "awaiting_input",
            "current_step": "awaiting_identity"
        }
    
    return {
        "messages": state["messages"] + [{"role": "assistant", "content": welcome_msg}],
        "user_role": user_role,
        "current_step": "ready",
        "processing_status": "awaiting_input"  # 等待用户提问
    }


async def qa_agent_node(state: State) -> Dict[str, Any]:
    """问答代理节点 - 为天文爱好者服务"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行问答代理节点")
    
    # 获取最后一条用户消息
    messages = state.get("messages", [])
    if not messages:
        return {"processing_status": "error"}
    
    last_message = messages[-1]
    user_input = last_message.get("content", "") if isinstance(last_message, dict) else str(last_message)
    
    # 检查是否是身份选择（避免重复处理）
    if user_input in ["爱好者", "爱好", "enthusiast", "天文爱好者", "专业", "professional", "研究者", "科学家"]:
        return {
            "processing_status": "awaiting_input"  # 等待用户提问
        }
    
    # 检查是否是退出命令
    if user_input.lower() in ["exit", "quit", "退出", "结束"]:
        return {
            "messages": state["messages"] + [{
                "role": "assistant", 
                "content": "感谢您的使用！再见！🌟"
            }],
            "processing_status": "completed"
        }
    
    try:
        # 创建简单的问答逻辑
        llm = Ollama(model="qwen2.5:7b")
        
        # 获取对话历史 - 参考deer-flow的方式
        messages = state.get("messages", [])
        
        conversation_history = ""
        for i, msg in enumerate(messages[-10:], 1):  # 取最近10条消息
            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = msg.get("content", "")
                if role == "user":
                    conversation_history += f"{i}. 用户: {content}\n"
                elif role == "assistant":
                    conversation_history += f"{i}. 助手: {content}\n"
            else:
                # 处理LangChain消息对象
                content = getattr(msg, 'content', str(msg))
                msg_type = type(msg).__name__
                if msg_type == "HumanMessage":
                    conversation_history += f"{i}. 用户: {content}\n"
                elif msg_type == "AIMessage":
                    conversation_history += f"{i}. 助手: {content}\n"
                else:
                    # 其他类型的消息
                    conversation_history += f"{i}. {msg_type}: {content}\n"
        
        # 构建提示词
        prompt = f"""你是专业的天文助手，请根据对话历史回答用户问题。

对话历史:
{conversation_history}

当前用户问题: {user_input}

要求：
- 提供详细、准确的天文知识
- 结合对话历史，理解用户真正想了解什么
- 如果用户问"上一个问题是什么"，请明确指出对话历史中的上一个用户问题
- 回答要实用，包含具体建议
- 如果涉及观测，提供具体的时间和地点建议
- 回答长度控制在200-300字"""
        
        response = await llm.ainvoke(prompt)
        
        return {
            "messages": state["messages"] + [{"role": "assistant", "content": response}],
            "processing_status": "awaiting_input"
        }
        
    except Exception as e:
        logger.error(f"问答代理执行出错: {e}")
        return {
            "messages": state["messages"] + [{"role": "assistant", "content": f"抱歉，处理您的请求时出现了错误: {str(e)}"}],
            "processing_status": "error"
        }


async def task_selector_node(state: State) -> Dict[str, Any]:
    """任务选择节点 - 为专业研究者提供任务选项"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行任务选择节点")
    
    # 获取最后一条用户消息
    messages = state.get("messages", [])
    if not messages:
        return {"processing_status": "error"}
    
    last_message = messages[-1]
    user_input = last_message.get("content", "") if isinstance(last_message, dict) else str(last_message)
    
    # 检查是否是首次进入任务选择（显示选项）
    if user_input in ["专业", "professional", "研究者", "科学家"] or not user_input.strip():
        return {
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": "🔬 欢迎！我是您的专业天文研究助手\n\n请选择您需要的服务类型：\n\n1️⃣ **分类** - 对天体目标或科学数据进行分类\n2️⃣ **数据检索** - 从公开数据库中查找和获取数据\n3️⃣ **文献综述辅助** - 根据主题生成相关文献列表和摘要\n\n请回复对应的数字或关键词（如：1、分类、数据检索等）"
            }],
            "current_step": "task_selection",
            "processing_status": "awaiting_input"
        }
    
    # 检查任务选择
    if "分类" in user_input or "classification" in user_input.lower() or user_input.strip() in ["1", "1️⃣"]:
        task = AstronomyTask(
            task_type="classification",
            target_object="",
            data_source="",
            classification_standard=""
        )
        return {
            "current_task": task,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": "您选择了分类任务。让我们一步步配置这个任务。\n\n首先，请告诉我您希望对哪一类天体进行分类？例如：恒星、星系、超新星、系外行星等。"
            }],
            "current_step": "classification_config",
            "processing_status": "awaiting_input"
        }
    
    elif "数据" in user_input or "data" in user_input.lower() or user_input.strip() in ["2", "2️⃣"]:
        task = AstronomyTask(task_type="data_retrieval")
        return {
            "current_task": task,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": "您选择了数据检索任务。请告诉我您需要检索什么类型的天文数据？"
            }],
            "current_step": "data_retrieval",
            "processing_status": "awaiting_input"
        }
    
    elif "文献" in user_input or "literature" in user_input.lower() or user_input.strip() in ["3", "3️⃣"]:
        task = AstronomyTask(task_type="literature_review")
        return {
            "current_task": task,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": "您选择了文献综述任务。请告诉我您需要综述什么主题的文献？"
            }],
            "current_step": "literature_review",
            "processing_status": "awaiting_input"
        }
    
    else:
        # 显示任务选项
        return {
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": """请选择您需要的专业服务：

1. **分类任务** - 对天体目标或科学数据进行分类
2. **数据检索** - 从公开数据库中查找和获取数据  
3. **文献综述** - 根据主题生成相关文献列表和摘要

请回复对应的数字或关键词来选择任务。"""
            }],
            "processing_status": "awaiting_input"
        }


async def classification_config_node(state: State) -> Dict[str, Any]:
    """分类配置节点"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行分类配置节点")
    
    current_task = state.get("current_task")
    if not current_task:
        return {"processing_status": "error"}
    
    # 获取最后一条用户消息
    messages = state.get("messages", [])
    last_message = messages[-1]
    user_input = last_message.get("content", "") if isinstance(last_message, dict) else str(last_message)
    
    # 根据当前配置步骤处理
    if not current_task.target_object:
        # 设置分类目标
        current_task.target_object = user_input
        return {
            "current_task": current_task,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"好的，您要分类 {user_input}。\n\n接下来请选择数据源：\n• SDSS API\n• ZTF Data Archive\n• NASA Exoplanet Archive\n• 其他（请指定）"
            }],
            "processing_status": "awaiting_input"
        }
    
    elif not current_task.data_source:
        # 设置数据源
        current_task.data_source = user_input
        return {
            "current_task": current_task,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"数据源设置为 {user_input}。\n\n最后，请选择分类标准：\n• 使用推荐标准（我会为您检索相关文献）\n• 自定义标准（请详细描述）"
            }],
            "processing_status": "awaiting_input"
        }
    
    elif not current_task.classification_standard:
        # 设置分类标准
        current_task.classification_standard = user_input
        return {
            "current_task": current_task,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"""配置完成！任务详情：
• 分类目标: {current_task.target_object}
• 数据源: {current_task.data_source}  
• 分类标准: {current_task.classification_standard}

现在开始生成执行代码..."""
            }],
            "processing_status": "ready_for_code_generation"
        }
    
    return {"processing_status": "error"}


async def background_investigation_node(state: State) -> Dict[str, Any]:
    """背景调研节点 - 使用Tavily搜索获取相关信息"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行背景调研节点")
    
    # 获取研究主题
    messages = state.get("messages", [])
    if not messages:
        return {"processing_status": "error"}
    
    last_message = messages[-1]
    query = last_message.get("content", "") if isinstance(last_message, dict) else str(last_message)
    
    try:
        # 使用Tavily搜索
        search_tool = get_web_search_tool(max_search_results=3)
        search_results = search_tool.invoke(query)
        
        if search_results:
            # 格式化搜索结果
            formatted_results = []
            for result in search_results:
                title = result.get("title", "无标题")
                content = result.get("content", "无内容")
                url = result.get("url", "")
                formatted_results.append(f"## {title}\n\n{content}\n\n来源: {url}")
            
            background_info = "\n\n".join(formatted_results)
            
            return {
                "messages": state["messages"] + [{
                    "role": "assistant",
                    "content": f"🔍 背景调研完成！\n\n{background_info}"
                }],
                "background_investigation_results": background_info,
                "processing_status": "completed"
            }
        else:
            return {
                "messages": state["messages"] + [{
                    "role": "assistant",
                    "content": "抱歉，没有找到相关的背景信息。"
                }],
                "processing_status": "completed"
            }
            
    except Exception as e:
        logger.error(f"背景调研失败: {e}")
        return {
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"背景调研过程中出现错误: {str(e)}"
            }],
            "processing_status": "error"
        }


async def data_retrieval_node(state: State) -> Dict[str, Any]:
    """数据检索节点"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行数据检索节点")
    
    return {
        "messages": state["messages"] + [{
            "role": "assistant",
            "content": "数据检索功能正在开发中..."
        }],
        "processing_status": "ready_for_code_generation"
    }


async def literature_review_node(state: State) -> Dict[str, Any]:
    """文献综述节点"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行文献综述节点")
    
    return {
        "messages": state["messages"] + [{
            "role": "assistant",
            "content": "文献综述功能正在开发中..."
        }],
        "processing_status": "ready_for_code_generation"
    }


async def code_generator_node(state: State) -> Dict[str, Any]:
    """代码生成节点"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行代码生成节点")
    
    current_task = state.get("current_task")
    if not current_task:
        return {"processing_status": "error"}
    
    # 生成简单的示例代码
    code = ""
    if current_task.task_type == "classification":
        code = f"""# 天文分类任务代码
# 目标: {current_task.target_object}
# 数据源: {current_task.data_source}
# 分类标准: {current_task.classification_standard}

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

def classify_celestial_objects():
    # 这里将实现具体的分类逻辑
    print("开始执行天文分类任务...")
    
    # 模拟数据加载
    data = pd.DataFrame({{
        'object_id': range(100),
        'feature1': np.random.randn(100),
        'feature2': np.random.randn(100),
        'class': np.random.choice(['A', 'B', 'C'], 100)
    }})
    
    # 训练分类模型
    X = data[['feature1', 'feature2']]
    y = data['class']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    
    # 预测
    predictions = model.predict(X_test)
    accuracy = model.score(X_test, y_test)
    
    print(f"分类准确率: {{accuracy:.2f}}")
    return predictions

if __name__ == "__main__":
    classify_celestial_objects()
"""
    else:
        # 默认代码
        code = """# 天文任务代码
print("天文任务执行中...")
print("任务完成！")
"""
    
    execution_result = ExecutionResult(
        version="v1",
        code=code,
        output="",
        success=False,
        error_message=""
    )
    
    return {
        "execution_result": execution_result,
        "messages": state["messages"] + [{
            "role": "assistant",
            "content": f"代码生成完成！\n\n```python\n{code}\n```\n\n现在开始执行代码..."
        }],
        "processing_status": "ready_for_execution"
    }


async def code_executor_node(state: State) -> Dict[str, Any]:
    """代码执行节点"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行代码执行节点")
    
    execution_result = state.get("execution_result")
    if not execution_result:
        return {"processing_status": "error"}
    
    try:
        # 模拟代码执行
        exec(execution_result.code)
        execution_result.success = True
        execution_result.output = "代码执行成功！分类任务完成。"
        
        return {
            "execution_result": execution_result,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"✅ 代码执行成功！\n\n{execution_result.output}\n\n结果已保存，请查看执行结果。"
            }],
            "processing_status": "ready_for_review"
        }
        
    except Exception as e:
        execution_result.success = False
        execution_result.error_message = str(e)
        
        return {
            "execution_result": execution_result,
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"❌ 代码执行失败：{str(e)}\n\n请检查代码或重新配置任务。"
            }],
            "processing_status": "error"
        }


async def result_review_node(state: State) -> Dict[str, Any]:
    """结果审查节点"""
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("执行结果审查节点")
    
    execution_result = state.get("execution_result")
    if not execution_result:
        return {"processing_status": "error"}
    
    if execution_result.success:
        return {
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"""📊 任务执行结果

版本: {execution_result.version}
状态: ✅ 成功
输出: {execution_result.output}

您对这个结果满意吗？
• 回复 '满意' - 结束任务
• 回复 '修改' - 重新配置任务
• 回复 '问答' - 跳转到问答模式"""
            }],
            "processing_status": "awaiting_feedback"
        }
    else:
        return {
            "messages": state["messages"] + [{
                "role": "assistant",
                "content": f"""❌ 任务执行失败

错误信息: {execution_result.error_message}

请选择下一步操作：
• 回复 '修改' - 重新配置任务
• 回复 '问答' - 跳转到问答模式获取帮助"""
            }],
            "processing_status": "awaiting_feedback"
        }
