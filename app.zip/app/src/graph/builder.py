# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

from .nodes import (
    coordinator_node,
    user_profiler_node,
    qa_agent_node,
    task_selector_node,
    background_investigation_node,
    classification_config_node,
    data_retrieval_node,
    literature_review_node,
    code_generator_node,
    code_executor_node,
    result_review_node,
)
from .types import State


def route_after_coordinator(state: State) -> str:
    """协调器后的路由
    
    根据对话历史和用户身份决定下一步：
    - 如果已经识别过身份，直接根据角色路由
    - 如果还没有识别身份，进入用户画像
    - 如果没有用户消息，结束流程
    """
    # 检查是否已经识别过身份
    user_role = state.get("user_role")
    if user_role and user_role != "unknown":
        # 已经识别过身份，直接根据角色路由
        if user_role == "enthusiast":
            return "qa_agent"
        elif user_role == "professional":
            return "task_selector"
    
    # 检查对话历史中是否有身份信息
    messages = state.get("messages", [])
    for message in messages:
        if isinstance(message, dict) and message.get("role") == "assistant":
            content = message.get("content", "")
            if "🌟 欢迎！我是您的天文小助手" in content:
                # 已经识别为爱好者
                return "qa_agent"
            elif "🔬 欢迎！我是您的专业天文研究助手" in content:
                # 已经识别为专业研究者
                return "task_selector"
    
    # 如果没有用户消息，结束流程
    if not messages:
        return END
    
    # 如果还没有识别身份，进入用户画像
    return "user_profiler"


def route_after_user_profiling(state: State) -> str:
    """用户画像后的路由
    
    根据用户身份和当前状态决定下一步：
    - awaiting_input: 身份识别完成，等待用户提问，结束当前流程
    - enthusiast: 天文爱好者，进入问答模式
    - professional: 专业研究者，进入任务选择模式
    - ready: 已准备好，根据用户角色路由
    - 其他: 继续身份识别
    """
    user_role = state.get("user_role", "unknown")
    processing_status = state.get("processing_status", "idle")
    
    # 如果已经识别过身份且状态为ready，直接根据角色路由
    if processing_status == "ready" and user_role != "unknown":
        if user_role == "enthusiast":
            return "qa_agent"
        elif user_role == "professional":
            return "task_selector"
    
    # 如果正在等待用户输入，结束流程
    if processing_status == "awaiting_input":
        return END
    
    # 根据用户角色路由
    if user_role == "enthusiast":
        return "qa_agent"
    elif user_role == "professional":
        return "task_selector"
    else:
        return "user_profiler"  # 身份未知，继续识别


def route_after_qa(state: State) -> str:
    """问答后的路由
    
    问答代理处理完用户问题后的路由逻辑：
    - awaiting_input: 等待用户下一个问题，结束当前流程
    - completed: 问答完成，结束流程
    - 其他: 默认结束流程
    """
    # 检查是否需要继续问答
    processing_status = state.get("processing_status", "idle")
    if processing_status == "awaiting_input":
        return END  # 等待用户输入，结束当前流程
    elif processing_status == "completed":
        return END  # 问答完成，结束流程
    else:
        return END  # 默认结束


def route_after_task_selection(state: State) -> str:
    """任务选择后的路由
    
    根据用户选择的任务类型路由到相应的配置节点：
    - classification: 天体分类任务 -> classification_config
    - data_retrieval: 数据检索任务 -> data_retrieval
    - literature_review: 文献检索任务 -> literature_review
    - 无任务或未知任务: 返回task_selector重新选择
    """
    current_task = state.get("current_task")
    if not current_task:
        return "task_selector"
    
    task_type = current_task.task_type
    if task_type == "classification":
        return "classification_config"
    elif task_type == "data_retrieval":
        return "data_retrieval"
    elif task_type == "literature_review":
        return "literature_review"
    else:
        return "task_selector"


def route_after_background_investigation(state: State) -> str:
    """背景调研后的路由
    
    根据调研结果和任务类型路由到相应的配置节点：
    - 默认根据current_task路由到相应配置节点
    """
    current_task = state.get("current_task")
    if not current_task:
        return "task_selector"
    
    task_type = current_task.task_type
    if task_type == "classification":
        return "classification_config"
    elif task_type == "data_retrieval":
        return "data_retrieval"
    elif task_type == "literature_review":
        return "literature_review"
    else:
        return "task_selector"


def route_after_config(state: State) -> str:
    """配置后的路由
    
    所有配置节点（分类、数据检索、文献检索）完成后都进入代码生成阶段
    """
    return "code_generator"


def route_after_code_generation(state: State) -> str:
    """代码生成后的路由
    
    代码生成完成后进入代码执行阶段
    """
    return "code_executor"


def route_after_execution(state: State) -> str:
    """执行后的路由
    
    代码执行完成后进入结果审查阶段
    """
    return "result_review"


def route_after_review(state: State) -> str:
    """审查后的路由
    
    根据用户对结果的反馈决定下一步：
    - needs_modification: 需要修改 -> task_selector (重新选择任务)
    - needs_qa: 需要问答 -> qa_agent (跳转到问答模式)
    - 其他: 满意结果 -> END (结束流程)
    """
    processing_status = state.get("processing_status", "idle")
    if processing_status == "needs_modification":
        return "task_selector"  # 返回任务选择重新配置
    elif processing_status == "needs_qa":
        return "qa_agent"  # 跳转到问答
    else:
        return END  # 满意，结束流程


def _build_base_graph():
    """构建基础状态图
    
    天文科研智能代理的工作流程图：
    1. coordinator -> user_profiler: 欢迎用户并引导身份识别
    2. user_profiler -> qa_agent/task_selector: 根据用户身份路由
    3. qa_agent: 为天文爱好者提供问答服务
    4. task_selector: 为专业研究者提供任务选择
    5. 专业任务流程: classification_config/data_retrieval/literature_review -> code_generator -> code_executor -> result_review
    """
    builder = StateGraph(State)
    
    # ==================== 添加所有节点 ====================
    # 入口节点
    builder.add_edge(START, "coordinator")  # 工作流从协调器开始
    builder.add_node("coordinator", coordinator_node)  # 协调器：欢迎用户，引导身份识别
    
    # 身份识别节点
    builder.add_node("user_profiler", user_profiler_node)  # 用户画像：识别用户身份（爱好者/专业）
    
    # 爱好者服务节点
    builder.add_node("qa_agent", qa_agent_node)  # 问答代理：为天文爱好者提供知识问答
    
    # 专业服务节点
    builder.add_node("task_selector", task_selector_node)  # 任务选择器：为专业研究者提供任务选项
    builder.add_node("background_investigation", background_investigation_node)  # 背景调研：使用Tavily搜索获取相关信息
    builder.add_node("classification_config", classification_config_node)  # 分类配置：天体分类任务配置
    builder.add_node("data_retrieval", data_retrieval_node)  # 数据检索：天文数据获取
    builder.add_node("literature_review", literature_review_node)  # 文献检索：学术文献搜索
    
    # 代码生成和执行节点
    builder.add_node("code_generator", code_generator_node)  # 代码生成器：生成Python代码
    builder.add_node("code_executor", code_executor_node)  # 代码执行器：运行生成的代码
    
    # 结果处理节点
    builder.add_node("result_review", result_review_node)  # 结果审查：展示结果并收集反馈
    
    # ==================== 添加边连接 ====================
    
    # 1. 协调器 -> 条件路由（根据对话历史决定是否进入用户画像）
    builder.add_conditional_edges(
        "coordinator",
        route_after_coordinator,
        ["user_profiler", "qa_agent", "task_selector", END]
    )
    
    # 2. 用户画像后的条件路由
    # 根据用户身份和状态决定下一步：
    # - enthusiast -> qa_agent (天文爱好者问答)
    # - professional -> task_selector (专业研究者任务选择)
    # - awaiting_input -> END (等待用户输入，结束当前流程)
    # - 其他 -> user_profiler (继续身份识别)
    builder.add_conditional_edges(
        "user_profiler",
        route_after_user_profiling,
        ["qa_agent", "task_selector", "user_profiler", END]
    )
    
    # 3. 问答代理后的条件路由
    # 问答完成后直接结束，等待用户下次输入
    builder.add_conditional_edges(
        "qa_agent",
        route_after_qa,
        ["qa_agent", END]
    )
    
    # 4. 任务选择器后的条件路由
    # 根据选择的任务类型路由到相应的配置节点
    builder.add_conditional_edges(
        "task_selector",
        route_after_task_selection,
        ["classification_config", "data_retrieval", "literature_review", "task_selector"]
    )
    
    # 5. 配置节点后的路由（分类、数据检索、文献检索）
    # 所有配置完成后都进入代码生成阶段
    builder.add_conditional_edges(
        "classification_config",
        route_after_config,
        ["code_generator"]
    )
    builder.add_conditional_edges(
        "data_retrieval",
        route_after_config,
        ["code_generator"]
    )
    builder.add_conditional_edges(
        "literature_review",
        route_after_config,
        ["code_generator"]
    )
    
    # 6. 代码生成 -> 代码执行（固定路径）
    builder.add_conditional_edges(
        "code_generator",
        route_after_code_generation,
        ["code_executor"]
    )
    
    # 7. 代码执行 -> 结果审查（固定路径）
    builder.add_conditional_edges(
        "code_executor",
        route_after_execution,
        ["result_review"]
    )
    
    # 8. 结果审查后的条件路由
    # 根据用户反馈决定下一步：
    # - 满意 -> END (任务完成)
    # - 修改 -> task_selector (重新选择任务)
    # - 问答 -> qa_agent (跳转到问答模式)
    builder.add_conditional_edges(
        "result_review",
        route_after_review,
        ["task_selector", "qa_agent", END]
    )
    
    return builder


def build_graph_with_memory():
    """构建带内存的图"""
    memory = MemorySaver()
    builder = _build_base_graph()
    return builder.compile(checkpointer=memory)


def build_graph():
    """构建图"""
    builder = _build_base_graph()
    return builder.compile()


graph = build_graph()
