# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import logging
from typing import Any, Dict, List, Optional, Type, Union

from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)


def create_logged_tool(tool_class: Type[BaseTool]) -> Type[BaseTool]:
    """Create a logged version of a tool that logs all invocations."""
    
    class LoggedTool(tool_class):
        def invoke(
            self,
            input: Union[str, Dict[str, Any]],
            config: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
        ) -> Union[str, List[Dict[str, Any]]]:
            """Invoke the tool with logging."""
            logger.info(f"Tool {self.name} invoked with input: {input}")
            try:
                result = super().invoke(input, config, **kwargs)
                logger.info(f"Tool {self.name} completed successfully")
                return result
            except Exception as e:
                logger.error(f"Tool {self.name} failed with error: {e}")
                raise
        
        async def ainvoke(
            self,
            input: Union[str, Dict[str, Any]],
            config: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
        ) -> Union[str, List[Dict[str, Any]]]:
            """Async invoke the tool with logging."""
            logger.info(f"Tool {self.name} async invoked with input: {input}")
            try:
                result = await super().ainvoke(input, config, **kwargs)
                logger.info(f"Tool {self.name} async completed successfully")
                return result
            except Exception as e:
                logger.error(f"Tool {self.name} async failed with error: {e}")
                raise
    
    return LoggedTool



