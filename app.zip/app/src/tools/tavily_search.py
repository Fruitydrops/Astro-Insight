# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import json
from typing import Any, Dict, List, Optional

from langchain_community.tools.tavily_search.tool import TavilySearchResults
from langchain_core.pydantic_v1 import Field

from .decorators import create_logged_tool


class SimpleTavilySearch(TavilySearchResults):
    """简化的Tavily搜索工具，适合天文研究需求."""
    
    name: str = "tavily_search"
    description: str = (
        "天文研究搜索工具。用于搜索最新的天文发现、研究论文和科学数据。"
        "输入应该是搜索查询。"
    )
    
    def _run(
        self,
        query: str,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """运行搜索工具."""
        try:
            # 调用父类方法获取JSON字符串
            json_str = super()._run(query, run_manager, **kwargs)
            # 解析JSON字符串为Python对象
            results = json.loads(json_str) if json_str else []
            return results
        except Exception as e:
            print(f"Tavily搜索错误: {e}")
            return []


# 创建带日志的版本
LoggedTavilySearch = create_logged_tool(SimpleTavilySearch)


def get_web_search_tool(max_search_results: int = 3):
    """获取网络搜索工具."""
    return LoggedTavilySearch(
        name="web_search",
        max_results=max_search_results,
    )
