# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from .search import get_web_search_tool

__all__ = ["get_web_search_tool"]
