# LLM集成实施计划文档

## 📋 项目概述

**项目名称：** 天文科研代理LLM集成  
**实施时间：** 2025年1月  
**技术栈：** Ollama + Qwen2.5:7b + LangChain + Tavily  
**部署方式：** 直接Python环境（本地部署）

## 🎯 需求确认

### 技术需求
- ✅ **LLM服务**: 本地部署 Ollama + Qwen2.5:7b
- ✅ **实时搜索**: Tavily搜索功能
- ✅ **对话记忆**: 智能对话历史管理
- ✅ **流式响应**: 实时token级别输出
- ✅ **多语言支持**: 中英文无缝切换
- ✅ **分阶段实施**: 3个阶段依次完成

### 性能要求
- **并发用户**: 无高要求（本地部署）
- **响应时间**: 尽量快速
- **成本考虑**: 本地模型，无成本限制
- **扩展性**: 为未来天文知识库预留接口

### 功能范围
- ✅ 实时搜索功能
- ✅ 对话记忆功能
- ✅ 流式响应功能
- ✅ 多语言功能
- ❌ 语音交互（暂不需要）
- ❌ 图像识别（暂不需要）
- ❌ 个性化推荐（暂不需要）
- ❌ 实时天文数据（暂不需要）

## 🏗️ 技术架构设计

### 核心架构
```
qa_agent_node
├── LLM调用层
│   ├── Ollama客户端 (Qwen2.5:7b)
│   ├── 流式响应处理
│   └── 模型管理
├── Prompt系统
│   ├── 多语言模板
│   ├── 天文知识库
│   └── 动态prompt生成
├── 搜索集成
│   ├── Tavily搜索
│   ├── 搜索上下文
│   └── 结果整合
├── 上下文管理
│   ├── 对话记忆
│   ├── 会话状态
│   └── 上下文优化
└── 工具层
    ├── 错误处理
    ├── 重试机制
    └── 性能监控
```

### 数据流设计
```
用户输入 → 语言检测 → 上下文构建 → Prompt生成 → 
LLM调用 → 流式响应 → 搜索增强 → 结果整合 → 响应输出
```

## 📁 文件结构规划

### 新增目录结构
```
src/agent/
├── llms/                    # LLM管理模块
│   ├── __init__.py
│   ├── ollama_client.py
│   ├── llm_manager.py
│   └── stream_handler.py
├── prompts/                 # Prompt系统
│   ├── __init__.py
│   ├── template_engine.py
│   └── astronomy/
│       ├── qa_agent_zh.md
│       └── qa_agent_en.md
├── tools/                   # 工具集成
│   ├── __init__.py
│   ├── search_tool.py
│   └── tool_manager.py
├── context/                 # 上下文管理
│   ├── __init__.py
│   ├── conversation_manager.py
│   └── memory_manager.py
└── config/
    ├── llm_config.py        # LLM配置
    └── search_config.py     # 搜索配置
```

## 🚀 分阶段实施计划

### 第一阶段：基础设施搭建（预计2-3天）

#### 1.1 依赖包配置
**目标：** 配置Ollama和LLM相关依赖

**需要添加的依赖：**
```toml
# pyproject.toml 新增依赖
"langchain-core>=0.3.0",
"langchain-community>=0.3.0", 
"langchain-ollama>=0.2.0",
"httpx>=0.27.0",
"jinja2>=3.1.0",
"tavily-python>=0.3.0",  # 实时搜索
"python-dotenv>=1.0.1"
```

#### 1.2 配置文件系统
**目标：** 创建支持Ollama的配置系统

**创建文件：**
- `conf.yaml` - 主配置文件
- `.env.example` - 环境变量模板
- `src/agent/config/llm_config.py` - LLM配置管理

**配置参数：**
```yaml
# conf.yaml
OLLAMA_CONFIG:
  base_url: "http://localhost:11434"
  model: "qwen2.5:7b"
  temperature: 0.7
  max_tokens: 2048
  timeout: 30

TAVILY_CONFIG:
  api_key: "${TAVILY_API_KEY}"
  max_results: 5
  search_depth: "basic"
```

#### 1.3 LLM管理模块
**目标：** 实现Ollama模型管理

**创建模块：**
- `src/agent/llms/ollama_client.py` - Ollama客户端
- `src/agent/llms/llm_manager.py` - LLM管理器
- `src/agent/llms/stream_handler.py` - 流式响应处理

**核心功能：**
- Ollama连接管理
- 模型调用封装
- 流式响应处理
- 错误处理和重试

#### 1.4 搜索工具集成
**目标：** 集成Tavily搜索功能

**创建模块：**
- `src/agent/tools/search_tool.py` - 搜索工具
- `src/agent/tools/tool_manager.py` - 工具管理器

**功能特性：**
- Tavily API集成
- 搜索结果格式化
- 搜索上下文管理

### 第二阶段：Prompt系统构建（预计2-3天）

#### 2.1 Prompt模板系统
**目标：** 创建灵活的模板系统

**创建结构：**
```
src/agent/prompts/
├── __init__.py
├── template_engine.py
├── astronomy/
│   ├── qa_agent_zh.md
│   ├── qa_agent_en.md
│   └── system_prompts.md
└── templates/
    ├── base_template.md
    └── conversation_template.md
```

**核心功能：**
- Jinja2模板引擎
- 动态变量替换
- 多语言模板支持
- 模板缓存机制

#### 2.2 天文知识Prompt设计
**目标：** 基于deer-flow设计专业的天文问答prompt

**Prompt特性：**
- 多语言支持（中英文）
- 角色定义清晰
- 知识领域覆盖全面
- 回答原则明确
- 可扩展的知识库接口

**知识领域覆盖：**
- 基础天文学（天体类型、天体系统、天文现象）
- 天体物理学（恒星演化、星系结构、宇宙学）
- 观测天文学（观测方法、天文仪器、观测技术）
- 太阳系科学（行星特征、卫星系统、小天体）

#### 2.3 上下文管理优化
**目标：** 实现智能的对话记忆

**功能模块：**
- `src/agent/context/conversation_manager.py` - 对话管理
- `src/agent/context/memory_manager.py` - 记忆管理
- `src/agent/context/context_optimizer.py` - 上下文优化

**核心功能：**
- 对话历史管理
- 上下文长度控制
- 记忆压缩和优化
- 多轮对话支持

### 第三阶段：LLM集成与功能实现（预计3-4天）

#### 3.1 qa_agent_node升级
**目标：** 集成完整的LLM调用功能

**核心功能：**
- Ollama模型调用
- 流式响应处理
- 实时搜索集成
- 对话记忆管理
- 多语言支持
- 错误处理和重试

**技术实现：**
```python
async def qa_agent_node(state: State, runtime: Runtime[Context]) -> Dict[str, Any]:
    # 1. 获取用户查询和上下文
    # 2. 语言检测
    # 3. 构建prompt
    # 4. 调用LLM（流式）
    # 5. 搜索增强（如需要）
    # 6. 结果整合
    # 7. 更新对话历史
    # 8. 返回响应
```

#### 3.2 流式响应实现
**目标：** 实现实时流式输出

**技术实现：**
- 使用LangChain的stream功能
- 实现token级别的流式输出
- 支持中断和恢复
- 异步处理优化

#### 3.3 搜索功能集成
**目标：** 集成Tavily实时搜索

**功能特性：**
- 智能搜索触发
- 搜索结果整合
- 搜索上下文管理
- 搜索缓存机制

#### 3.4 多语言支持
**目标：** 实现中英文无缝切换

**实现方式：**
- 语言检测算法
- 动态prompt切换
- 响应语言适配
- 语言一致性保证

## 🔧 技术配置详情

### Ollama配置
```yaml
OLLAMA_CONFIG:
  base_url: "http://localhost:11434"
  model: "qwen2.5:7b"
  temperature: 0.7
  max_tokens: 2048
  timeout: 30
  max_retries: 3
  verify_ssl: true
```

### Tavily配置
```yaml
TAVILY_CONFIG:
  api_key: "${TAVILY_API_KEY}"
  max_results: 5
  search_depth: "basic"
  include_domains: []
  exclude_domains: []
  timeout: 10
```

### 环境变量
```bash
# .env
TAVILY_API_KEY=your_tavily_api_key_here
OLLAMA_BASE_URL=http://localhost:11434
DEBUG_MODE=false
LOG_LEVEL=INFO
```

## 📊 实施时间表

### 第一阶段（基础设施）- 预计2-3天
- **Day 1**: 依赖配置 + Ollama客户端
- **Day 2**: LLM管理模块 + 基础配置
- **Day 3**: 搜索工具集成 + 测试验证

### 第二阶段（Prompt系统）- 预计2-3天  
- **Day 1**: 模板引擎 + 基础模板
- **Day 2**: 天文知识Prompt设计
- **Day 3**: 上下文管理优化

### 第三阶段（LLM集成）- 预计3-4天
- **Day 1-2**: qa_agent_node升级 + 流式响应
- **Day 3**: 搜索功能集成
- **Day 4**: 多语言支持 + 最终测试

## 🧪 测试策略

### 单元测试
- LLM调用测试
- Prompt模板测试
- 搜索功能测试
- 上下文管理测试

### 集成测试
- 端到端对话测试
- 多语言切换测试
- 流式响应测试
- 错误处理测试

### 性能测试
- 响应时间测试
- 内存使用测试
- 并发处理测试

## 🔍 关键技术点

### 1. Ollama集成
- 使用`langchain-ollama`包
- 支持本地模型调用
- 实现连接池和重试机制
- 错误处理和降级策略

### 2. 流式响应
- 使用LangChain的`stream`方法
- 实现token级别的实时输出
- 支持用户中断
- 异步处理优化

### 3. 搜索增强
- 集成Tavily搜索API
- 智能搜索触发机制
- 搜索结果与LLM响应整合
- 搜索缓存和优化

### 4. 多语言支持
- 基于用户输入自动检测语言
- 动态切换prompt模板
- 保持对话语言一致性
- 语言检测准确性优化

## 📝 开发规范

### 代码规范
- 遵循PEP 8标准
- 使用类型注解
- 完整的文档字符串
- 单元测试覆盖

### 错误处理
- 优雅的错误处理
- 详细的错误日志
- 用户友好的错误信息
- 自动重试机制

### 性能优化
- 异步处理
- 连接池管理
- 缓存机制
- 内存优化

## 🚨 风险控制

### 技术风险
- Ollama服务不可用
- 网络连接问题
- 模型响应异常
- 内存溢出

### 缓解措施
- 健康检查机制
- 自动重试策略
- 降级处理方案
- 资源监控告警

## 📋 验收标准

### 功能验收
- ✅ LLM调用正常
- ✅ 流式响应工作
- ✅ 搜索功能集成
- ✅ 多语言支持
- ✅ 对话记忆正常

### 性能验收
- ✅ 响应时间 < 3秒
- ✅ 内存使用 < 2GB
- ✅ 错误率 < 1%
- ✅ 可用性 > 99%

## 📚 参考资源

### 技术文档
- [LangChain Ollama集成](https://python.langchain.com/docs/integrations/llms/ollama)
- [Tavily搜索API](https://docs.tavily.com/)
- [Jinja2模板引擎](https://jinja.palletsprojects.com/)

### 项目参考
- deer-flow项目架构
- 现有天文科研代理代码
- LangGraph最佳实践

## 📞 联系信息

**项目负责人：** AI Assistant  
**创建时间：** 2025年1月  
**最后更新：** 2025年1月  
**文档版本：** v1.0

---

**注意：** 本文档为硬性备份，记录了完整的LLM集成实施计划。所有实施步骤应严格按照此文档执行，如有变更需及时更新文档。
