#!/usr/bin/env python3
# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def main():
    """主函数 - 单次运行"""
    if len(sys.argv) > 1:
        user_input = " ".join(sys.argv[1:])
    else:
        user_input = input("请输入您的问题: ").strip()
    
    if not user_input:
        print("❌ 输入不能为空")
        return
    
    print("🌟 天文科研智能代理启动中...")
    print("=" * 50)
    
    await run_astronomy_workflow_async(user_input, debug=True)
    
    print("=" * 50)
    print("✅ 任务完成！")

if __name__ == "__main__":
    asyncio.run(main())



