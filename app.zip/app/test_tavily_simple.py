#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import asyncio
import logging

# 设置环境变量
os.environ["TAVILY_API_KEY"] = "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"
os.environ["SEARCH_API"] = "tavily"

# 设置日志
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

async def test_tavily():
    """测试Tavily搜索功能"""
    print("🔍 测试Tavily搜索集成...")
    
    try:
        from src.tools.search import get_web_search_tool
        
        # 获取搜索工具
        search_tool = get_web_search_tool(max_search_results=2)
        print(f"✅ 搜索工具创建成功: {search_tool.name}")
        
        # 执行搜索测试
        query = "系外行星最新发现 2024"
        print(f"🔎 搜索查询: {query}")
        
        results = search_tool.invoke(query)
        print(f"📊 搜索结果数量: {len(results) if results else 0}")
        
        if results:
            print("\n📋 搜索结果预览:")
            for i, result in enumerate(results[:2], 1):
                title = result.get("title", "无标题")
                content = result.get("content", "无内容")[:200] + "..."
                url = result.get("url", "无链接")
                print(f"\n{i}. {title}")
                print(f"   内容: {content}")
                print(f"   链接: {url}")
        else:
            print("❌ 没有搜索结果")
            
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_tavily())



