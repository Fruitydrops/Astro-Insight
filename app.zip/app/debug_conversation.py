#!/usr/bin/env python3
"""
调试对话历史
"""

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def debug_conversation():
    """调试对话历史"""
    print("🔍 调试对话历史...")
    print("=" * 50)
    
    # 模拟用户输入
    inputs = [
        "你好",
        "爱好者", 
        "天文观测技巧",
        "我上一个问题是什么"
    ]
    
    for i, user_input in enumerate(inputs, 1):
        print(f"\n📝 步骤{i}：{user_input}")
        print(f"输入：{user_input}")
        await run_astronomy_workflow_async(user_input, debug=True)
        print("\n" + "-" * 30)

if __name__ == "__main__":
    asyncio.run(debug_conversation())
