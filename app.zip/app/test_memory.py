#!/usr/bin/env python3
"""
测试记忆功能的脚本
测试流程：
1. 明确身份（爱好者）
2. 提问（天文观测技巧）
3. 询问第一个问题
4. 验证是否能正确回答
"""

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def test_memory():
    """测试记忆功能"""
    print("🧪 开始测试记忆功能...")
    print("=" * 50)
    
    # 测试步骤1：明确身份
    print("\n📝 步骤1：明确身份")
    print("输入：爱好者")
    await run_astronomy_workflow_async("爱好者", debug=True)
    
    # 测试步骤2：提问
    print("\n📝 步骤2：提问")
    print("输入：天文观测技巧")
    await run_astronomy_workflow_async("天文观测技巧", debug=True)
    
    # 测试步骤3：询问第一个问题
    print("\n📝 步骤3：询问第一个问题")
    print("输入：我的第一个问题是什么")
    await run_astronomy_workflow_async("我的第一个问题是什么", debug=True)
    
    # 测试步骤4：询问记忆
    print("\n📝 步骤4：询问记忆")
    print("输入：你有记忆吗")
    await run_astronomy_workflow_async("你有记忆吗", debug=True)
    
    print("\n" + "=" * 50)
    print("✅ 测试完成")

if __name__ == "__main__":
    asyncio.run(test_memory())

