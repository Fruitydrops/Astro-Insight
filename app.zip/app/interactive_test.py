#!/usr/bin/env python3
# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def interactive_test():
    """交互式测试天文代理"""
    print("🌟 天文科研智能代理 - 交互式测试")
    print("=" * 50)
    print("💡 输入 'exit' 或 'quit' 退出程序")
    print("=" * 50)
    
    while True:
        try:
            user_input = input("\n👤 您: ").strip()
            
            if user_input.lower() in ['exit', 'quit', '退出']:
                print("👋 再见！")
                break
            
            if not user_input:
                continue
            
            print("🔄 处理中...")
            await run_astronomy_workflow_async(user_input, debug=False)
            print("\n" + "-" * 50)
            
        except KeyboardInterrupt:
            print("\n👋 再见！")
            break
        except Exception as e:
            print(f"❌ 发生错误: {e}")
            print("请重试...")

if __name__ == "__main__":
    asyncio.run(interactive_test())



