#!/usr/bin/env python3
"""测试天文代理的完整流程"""

import asyncio
from src.workflow import run_astronomy_workflow_async

async def test_flow():
    """测试完整流程"""
    print("=== 测试1: 身份识别 ===")
    await run_astronomy_workflow_async("爱好者")
    
    print("\n=== 测试2: 天文问题 ===")
    await run_astronomy_workflow_async("什么是流星雨？")

if __name__ == "__main__":
    asyncio.run(test_flow())



