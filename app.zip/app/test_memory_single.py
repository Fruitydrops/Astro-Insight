#!/usr/bin/env python3
"""
测试记忆功能的脚本 - 使用单个会话
测试流程：
1. 明确身份（爱好者）
2. 提问（天文观测技巧）
3. 询问第一个问题
4. 验证是否能正确回答
"""

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def test_memory_single_session():
    """测试记忆功能 - 单个会话"""
    print("🧪 开始测试记忆功能（单个会话）...")
    print("=" * 50)
    
    # 模拟用户在一个会话中的连续输入
    test_inputs = [
        "爱好者",  # 明确身份
        "天文观测技巧",  # 第一个问题
        "我的第一个问题是什么",  # 询问第一个问题
        "你有记忆吗"  # 询问记忆
    ]
    
    for i, user_input in enumerate(test_inputs, 1):
        print(f"\n📝 步骤{i}：{user_input}")
        print(f"输入：{user_input}")
        await run_astronomy_workflow_async(user_input, debug=True)
        print("\n" + "-" * 30)
    
    print("\n" + "=" * 50)
    print("✅ 测试完成")

if __name__ == "__main__":
    asyncio.run(test_memory_single_session())

