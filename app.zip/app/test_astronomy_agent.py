#!/usr/bin/env python3
# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.workflow import run_astronomy_workflow_async

async def test_astronomy_agent():
    """测试天文代理"""
    print("🌟 天文科研智能代理测试")
    print("=" * 50)
    
    # 测试用例1：天文爱好者问答
    print("\n📝 测试用例1：天文爱好者问答")
    print("-" * 30)
    await run_astronomy_workflow_async("爱好者", debug=True)
    
    print("\n" + "=" * 50)
    
    # 测试用例2：专业研究者任务选择
    print("\n📝 测试用例2：专业研究者任务选择")
    print("-" * 30)
    await run_astronomy_workflow_async("专业", debug=True)

if __name__ == "__main__":
    asyncio.run(test_astronomy_agent())



