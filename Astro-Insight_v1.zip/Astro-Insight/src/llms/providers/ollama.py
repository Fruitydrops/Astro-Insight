from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.outputs import LLMResult, ChatGeneration
from langchain_openai import ChatOpenAI
import json
import requests
from typing import Optional, Any, Dict, List, Iterator, Union
from pydantic import Field


class ChatOllama(ChatOpenAI):
    """Ollama聊天模型包装类"""
    
    model: str = Field(default="qwen2.5:7b")
    base_url: str = Field(default="http://localhost:11434")
    temperature: float = Field(default=0.7)
    max_tokens: int = Field(default=2048)
    timeout: int = Field(default=30)
    max_retries: int = Field(default=3)
    verify_ssl: bool = Field(default=True)
    
    # Ollama特定字段
    ollama_model: str = Field(default="qwen2.5:7b")
    ollama_base_url: str = Field(default="http://localhost:11434")
    ollama_timeout: int = Field(default=30)
    ollama_verify_ssl: bool = Field(default=True)
    
    def __init__(
        self,
        model: str = "qwen2.5:7b",
        base_url: str = "http://localhost:11434",
        temperature: float = 0.7,
        max_tokens: int = 2048,
        timeout: int = 30,
        max_retries: int = 3,
        verify_ssl: bool = True,
        **kwargs: Any
    ):
        """初始化Ollama聊天模型
        
        Args:
            model: 模型名称
            base_url: Ollama服务地址
            temperature: 温度参数
            max_tokens: 最大token数
            timeout: 超时时间
            max_retries: 最大重试次数
            verify_ssl: 是否验证SSL
            **kwargs: 其他参数
        """
        # 设置OpenAI兼容的配置
        openai_config = {
            "model": model,
            "base_url": f"{base_url.rstrip('/')}/v1",  # Ollama使用/v1路径
            "api_key": "ollama",  # Ollama不需要真实的API密钥
            "temperature": temperature,
            "max_tokens": max_tokens,
            "timeout": timeout,
            "max_retries": max_retries,
            "verify_ssl": verify_ssl,
            **kwargs
        }
        
        super().__init__(**openai_config)
        
        # 保存原始配置
        self.ollama_model = model
        self.ollama_base_url = base_url.rstrip('/')
        self.ollama_timeout = timeout
        self.ollama_verify_ssl = verify_ssl
    
    def _call(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """调用Ollama API"""
        # 构建消息格式
        formatted_messages = self._format_messages(messages)
        
        # 构建请求数据
        data = {
            "model": self.ollama_model,
            "messages": formatted_messages,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
            }
        }
        
        # 添加停止词
        if stop:
            data["options"]["stop"] = stop
            
        # 发送请求
        try:
            response = requests.post(
                f"{self.ollama_base_url}/v1/chat/completions",
                json=data,
                timeout=self.ollama_timeout,
                verify=self.ollama_verify_ssl
            )
            response.raise_for_status()
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Ollama API调用失败: {str(e)}")
    
    def _format_messages(self, messages: List[BaseMessage]) -> List[Dict[str, str]]:
        """格式化消息为Ollama API格式"""
        formatted = []
        for message in messages:
            if isinstance(message, HumanMessage):
                formatted.append({"role": "user", "content": message.content})
            elif isinstance(message, AIMessage):
                formatted.append({"role": "assistant", "content": message.content})
            elif isinstance(message, SystemMessage):
                formatted.append({"role": "system", "content": message.content})
        return formatted
    
    @property
    def _llm_type(self) -> str:
        """返回LLM类型"""
        return "ollama"
    
    @classmethod
    def from_config(cls, config: Dict[str, Any]) -> "ChatOllama":
        """从配置创建实例
        
        Args:
            config: 配置字典
            
        Returns:
            ChatOllama实例
        """
        return cls(
            model=config.get('model', 'qwen2.5:7b'),
            base_url=config.get('base_url', 'http://localhost:11434'),
            temperature=config.get('temperature', 0.7),
            max_tokens=config.get('max_tokens', 2048),
            timeout=config.get('timeout', 30),
            max_retries=config.get('max_retries', 3),
            verify_ssl=config.get('verify_ssl', True),
            **{k: v for k, v in config.items() if k not in [
                'model', 'base_url', 'temperature', 'max_tokens', 
                'timeout', 'max_retries', 'verify_ssl'
            ]}
        )